# Installing the Airbench beta

Thanks for testing Airbench. It needs macOS 13 or later and works on Apple silicon and Intel Macs.
Everything is unlocked during the beta.

## Install (2 minutes, once)

1. Unzip the file and drag **Airbench** into your **Applications** folder.
2. Open Airbench. macOS says it can't check the app for malicious software, because the beta isn't
   signed with an Apple Developer account yet. Click **Done**.
3. Open **System Settings > Privacy & Security** and scroll down to **Security**. Next to
   "Airbench was blocked", click **Open Anyway** and enter your Mac password.
4. Open Airbench again and click **Open**. From now on it opens normally.

## What Airbench may ask for

- **Full Disk Access** (optional): lets Storage look in more places, such as Mail and Messages caches.
  Without it, Airbench scans what it can and tells you what it skipped.
- **Control of your browser** (only when you use Review Tabs): lets Airbench list your tabs and close
  the ones you tick. Nothing else.
- To see each tab's memory in Brave, Chrome or Edge, turn on
  **View > Developer > Allow JavaScript from Apple Events** in that browser.

Your files never leave your Mac. Files are only ever moved to the Trash or into folders, and you can put them
back from History.

## Usage sharing (optional)

This is off unless you tick it during setup. If you turn it on, Airbench sends which features are used,
errors, and crash summaries, so bugs can be fixed. It never sends file names, folders, tabs, websites,
or anything personal. Settings > General turns it off.

## Feedback

Reply to the message this beta came with: what confused you, what broke, and what you'd pay for.
