# Installing the Airbench beta

Thanks for testing Airbench. It needs macOS 13 or later and works on Apple silicon and Intel Macs.
Everything is unlocked during the beta.

## Install (2 minutes, once)

1. Unzip the file and drag **Airbench** into your **Applications** folder.
2. Open the **Terminal** app, paste this line and press Return:

   `xattr -dr com.apple.quarantine /Applications/Airbench.app`

3. Open Airbench. From now on it opens like any other app.

The beta isn't signed with an Apple Developer account yet, so macOS may say Airbench "is damaged and can't be
opened". It isn't damaged. The line in step 2 only removes the "downloaded from the internet" tag macOS adds to
downloads. If you already saw that message, click **Cancel** (not Move to Bin), then do step 2.

## What Airbench may ask for

- **Full Disk Access** (optional): lets Storage look in more places, such as Mail and Messages caches.
  Without it, Airbench scans what it can and tells you what it skipped.
- **Control of your browser** (only when you use Review Tabs): lets Airbench list your tabs and close
  the ones you tick. Nothing else.
- To see each tab's memory in Brave, Chrome or Edge, turn on
  **View > Developer > Allow JavaScript from Apple Events** in that browser.

Your files never leave your Mac. Files are only ever moved to the Trash or into folders, and you can put them
back from History.

## Usage sharing (optional)

This is off unless you tick it during setup. If you turn it on, Airbench sends which features are used,
errors, and crash summaries, so bugs can be fixed. It never sends file names, folders, tabs, websites,
or anything personal. Settings > General turns it off.

## Feedback

Reply to the message this beta came with: what confused you, what broke, and what you'd pay for.
